<?php 

class C_Datamobil extends Controller{
	public function __construct(){
		$this->addFunction('url');
		// if(!isset($_SESSION['login'])) {
		// 	$_SESSION['error'] = 'Anda harus masuk dulu!';
		// 	header('Location: ' . base_url());
		// }
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->merk = $this->model('M_Merk');
		$this->transaksi = $this->model('M_Transaksi');
		$this->j_bayar = $this->model('M_Jenis_Bayar');
		$this->kendaraan = $this->model('M_Kendaraan');
		$this->penyewa = $this->model('M_Penyewa');
		$this->fasilitas = $this->model('M_Fasilitas');
		$this->karyawan = $this->model('M_Karyawan');
		$this->promosi = $this->model('M_Promosi');
	}

    public function index(){
		
		$data['kendaraan'] = $this->kendaraan->weblihat(array());
		$this->view('webpage/datamobil', $data);
		// $data['kendaraan']= [
		// 	'aktif' => 'kendaraan',
		// 	'judul' => 'Data Kendaraan',
		// 	'data_merk' => $this->merk->lihat(),
		// 	'data_kendaraan' => $this->kendaraan->weblihat()->fetch_object(),
		// ];
		
		// // $data['kendaraan'] = $this->kendaraan->weblihat();
		// $this->view('webpage/datamobil', $data);
	}

	public function detail($id){
		$data['detail'] = $this->transaksi->detail($id)->fetch_object();
		$this->view('datamobil', $data);
	}
}