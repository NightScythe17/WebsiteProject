<?php 

class C_Transaksi extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web'); 
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->transaksi = $this->model('M_Transaksi');
		$this->j_bayar = $this->model('M_Jenis_Bayar');
		$this->kendaraan = $this->model('M_Kendaraan');
		$this->penyewa = $this->model('M_Penyewa');
		$this->fasilitas = $this->model('M_Fasilitas');
		$this->karyawan = $this->model('M_Karyawan');
		$this->promosi = $this->model('M_Promosi');
		$this->denda = $this->model('M_Denda');
	}

	public function index(){
		$data = [
			'aktif' => 'transaksi',
			'judul' => 'Data Transaksi',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('transaksi/index', $data);
	}

	public function pengembalian(){
		$data = [
			'aktif' => 'transaksi',
			'judul' => 'Data Pengembalian',
			'data_transaksi' => $this->transaksi->wlihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('transaksi/pengembalian', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('transaksi');
		
		$data = [
			'kode_jual' => $this->req->post('kode_jual'),
			'id_penyewa' => $this->req->post('id_penyewa'),
			'id_karyawan' => $this->req->post('id_karyawan'),
			'id_kendaraan' => $this->req->post('id_kendaraan'),
			'id_fasilitas' => $this->req->post('id_fasilitas'),
			'id_promosi' => $this->req->post('id_promosi'),
			'id_jenis_bayar' => $this->req->post('id_jenis_bayar'),
			'tgl_pinjam' => $this->req->post('tgl_pinjam'),
			'tgl_kembali' => $this->req->post('tgl_kembali'),
			'tgl_kembalikan' => $this->req->post('tgl_kembali'),
			'test' => $this->req->post('test'),
			'denda' => $this->req->post('denda'),
		];

		if($this->transaksi->tambah($data)){
			setSession('success', 'Data berhasil ditambahkan!');
			redirect('transaksi');
		} else {
			setSession('error', 'Data gagal ditambahkan!');
			redirect('transaksi');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->transaksi->cek($id)->num_rows == 0) redirect('transaksi');
		$transaksi = $this->transaksi->lihat_id($id)->fetch_object();
		$id_penyewa = $transaksi->id_penyewa;
		$id_karyawan = $transaksi->id_karyawan;
		$id_kendaraan = $transaksi->id_kendaraan;
		$id_fasilitas = $transaksi->id_fasilitas;
		$id_promosi = $transaksi->id_promosi;
		$id_jenis_bayar = $transaksi->id_jenis_bayar;
		$data = [
			'aktif' => 'transaksi',
			'judul' => 'Ubah Transaksi',
			'penyewa' => $this->penyewa->lihat_id($id_penyewa)->fetch_object(),
			'karyawan' => $this->karyawan->lihat_id($id_karyawan)->fetch_object(),
			'kendaraan' => $this->kendaraan->lihat_id($id_kendaraan)->fetch_object(),
			'fasilitas' => $this->fasilitas->lihat_id($id_fasilitas)->fetch_object(),
			'promosi' => $this->promosi->lihat_id($id_promosi)->fetch_object(),
			'jenis_bayar' => $this->j_bayar->lihat_id($id_jenis_bayar)->fetch_object(),
			'transaksi' => $transaksi
		];
		$this->view('transaksi/ubah', $data);
	}

	public function pubah($id){
		if(!isset($id) || $this->transaksi->cek($id)->num_rows == 0) redirect('transaksi/pengembalian');
		$transaksi = $this->transaksi->lihat_id($id)->fetch_object();
		$id_penyewa = $transaksi->id_penyewa;
		$id_karyawan = $transaksi->id_karyawan;
		$id_kendaraan = $transaksi->id_kendaraan;
		$id_fasilitas = $transaksi->id_fasilitas;
		$id_promosi = $transaksi->id_promosi;
		$id_jenis_bayar = $transaksi->id_jenis_bayar;
		$data = [
			'aktif' => 'transaksi',
			'judul' => 'Ubah Transaksi',
			'penyewa' => $this->penyewa->lihat_id($id_penyewa)->fetch_object(),
			'karyawan' => $this->karyawan->lihat_id($id_karyawan)->fetch_object(),
			'kendaraan' => $this->kendaraan->lihat_id($id_kendaraan)->fetch_object(),
			'fasilitas' => $this->fasilitas->lihat_id($id_fasilitas)->fetch_object(),
			'promosi' => $this->promosi->lihat_id($id_promosi)->fetch_object(),
			'jenis_bayar' => $this->j_bayar->lihat_id($id_jenis_bayar)->fetch_object(),
			'transaksi' => $transaksi
		];
		$this->view('transaksi/pubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->transaksi->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('transaksi');

		$data = [
			'tgl_kembali' => $this->req->post('tgl_kembali'),
		];
		if($this->transaksi->ubah($data, $id)){
			setSession('success', 'Data berhasil diubah!');
			redirect('transaksi');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('transaksi');
		}
	}

	public function p_ubah($id){
		if(!isset($id) || $this->transaksi->cek($id)->num_rows == 0 || !isset($_POST['pubah'])) redirect('transaksi');

		$data = [
			'test' => $this->req->post('test'),
			'denda' => $this->req->post('denda'),
			'tgl_kembalikan' => $this->req->post('tgl_kembalikan'),
		];
		if($this->transaksi->ubah($data, $id)){
			setSession('success', 'Data berhasil diubah!');
			redirect('transaksi/pengembalian');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('transaksi/pengembalian');
		}
	}

	public function hapus($id = null){
		if(!isset($id) || $this->transaksi->cek($id)->num_rows == 0) redirect('transaksi');

		if($this->transaksi->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('transaksi');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('transaksi');
		}
	}

	public function detail($id){
		if(!isset($id) || $this->transaksi->cek($id)->num_rows == 0) redirect('transaksi');

		$data = [
			'aktif' => 'transaksi',
			'judul' => 'Detail Transaksi',
			'transaksi' => $this->transaksi->detail($id)->fetch_object(),
		];

		$this->view('transaksi/detail', $data);
	}
}