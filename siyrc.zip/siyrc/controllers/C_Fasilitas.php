<?php 

class C_Fasilitas extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->fasilitas = $this->model('M_Fasilitas');
	}

	public function index(){
		$data = [
			'aktif' => 'fasilitas',
			'judul' => 'Data Fasilitas',
			'data_fasilitas' => $this->fasilitas->lihat(),
			'no' => 1
		];
		$this->view('fasilitas/index', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('fasilitas');

        $data = [
            'nama' => $this->req->post('nama'),
            'fprice' => $this->req->post('fprice')
        ];
        
		if($this->fasilitas->tambah($data)){
			setSession('success', 'Data berhasil ditambahkan!');
			redirect('fasilitas');
		} else {
			setSession('error', 'Data gagal ditambahkan!');
			redirect('fasilitas');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->fasilitas->cek($id)->num_rows == 0) redirect('fasilitas');

		$data = [
			'aktif' => 'fasilitas',
			'judul' => 'Ubah Fasilitas',
			'fasilitas' => $this->fasilitas->lihat_id($id)->fetch_object(),
		];
		$this->view('fasilitas/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->fasilitas->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('fasilitas');

		$data = [
			'nama' => $this->req->post('nama'),
            'fprice' => $this->req->post('fprice'),
		];
		if($this->fasilitas->ubah($data, $id)){
			setSession('success', 'Data berhasil diubah!');
			redirect('fasilitas');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('fasilitas');
		}
	}

	public function hapus($id = null){
		if(!isset($id) || $this->fasilitas->cek($id)->num_rows == 0) redirect('fasilitas');

		if($this->fasilitas->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('fasilitas');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('fasilitas');
		}
	}
}