<?php 

class C_Penyewa extends Controller{
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->penyewa = $this->model('M_Penyewa');
	}

	public function index(){
		$data = [
			'aktif' => 'penyewa',
			'judul' => 'Data penyewa',
			'data_penyewa' => $this->penyewa->lihat(),
			'no' => 1
		];
		$this->view('penyewa/index', $data);
	}

	public function dashboard(){
		$data = [
			'aktif' => 'penyewa',
			'judul' => 'Data penyewa',
			'data_penyewa' => $this->penyewa->lihat(),
			'no' => 1
		];
		$this->view('penyewa/dashboard', $data);
	}

	public function detail($id){
		if(!isset($id) || $this->penyewa->cek($id)->num_rows == 0) redirect('penyewa');

		$data = [
			'aktif' => 'penyewa',
			'judul' => 'Detail Penyewa',
			'penyewa' => $this->penyewa->detail($id)->fetch_object(),
		];

		$this->view('penyewa/detail', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('penyewa');

		// proses upload
		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['foto']['tmp_name'];
		$ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['foto']['error'];

		$img_name = $this->req->post('nama');
		$img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		if($error == 0){
			if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
			if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
				$data = [
					'nama' => $this->req->post('nama'),
					'alamat' => $this->req->post('alamat'),
					'gender' => $this->req->post('gender'),
					'nik' => $this->req->post('nik'), 
					'phone' => $this->req->post('phone'),
					'email' => $this->req->post('email'),
					'birth' => $this->req->post('birth'),
					'foto' => $img_name . '.' . $ekstensi,
				];

				if($this->penyewa->tambah($data)){
					setSession('success', 'Data berhasil ditambahkan!');
					redirect('penyewa');
				} else {
					setSession('error', 'Data gagal ditambahkan!');
					redirect('penyewa');
				}
			} else die('gagal upload gambar');
		} else die('gambar error');
	}

	public function hapus($id = null){
		if(!isset($id) || $this->penyewa->cek($id)->num_rows == 0) redirect('penyewa');

		$gambar	= $this->penyewa->detail($id)->fetch_object()->foto;

		unlink(BASEPATH . DS . 'uploads' . DS . $gambar) or die('gagal hapus gambar!');
		if($this->penyewa->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('penyewa');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('penyewa');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->penyewa->cek($id)->num_rows == 0) redirect('penyewa');

		$data = [
			'aktif' => 'penyewa',
			'judul' => 'Ubah penyewa',
			'penyewa' => $this->penyewa->lihat_id($id)->fetch_object(),
		];
		$this->view('penyewa/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->penyewa->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('penyewa');

		// proses upload
		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['foto']['tmp_name'];
		$ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['foto']['error'];

		$img_name = $this->req->post('nama');
		$img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		if($error == 0){
			if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
			if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
				$data = [
					'nama' => $this->req->post('nama'),
					'alamat' => $this->req->post('alamat'),
					'gender' => $this->req->post('gender'),
					'nik' => $this->req->post('nik'),
					'phone' => $this->req->post('phone'),
					'email' => $this->req->post('email'),
					'birth' => $this->req->post('birth'),
					'foto' => $img_name . '.' . $ekstensi,
				];

				if($this->penyewa->ubah($data, $id)){
					setSession('success', 'Data berhasil diubah!');
					redirect('penyewa');
				} else {
					setSession('error', 'Data gagal diubah!');
					redirect('penyewa');
				}
			} else die('gagal upload gambar');
		} else die('gambar error');
	}
}