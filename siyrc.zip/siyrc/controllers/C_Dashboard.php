<?php 

class C_Dashboard extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}

		$this->addFunction('web');
		$this->kendaraan = $this->model('M_Kendaraan');
		$this->penyewa = $this->model('M_Penyewa');
		$this->transaksi = $this->model('M_Transaksi');
		$this->user = $this->model('M_User');
		$this->karyawan = $this->model('M_Karyawan');
	}
	public function index(){
		$data = [
			'aktif' => 'dashboard',
			'judul' => 'Dashboard',
			'kendaraan' => $this->kendaraan->lihat(),
			'penyewa' => $this->penyewa->lihat(),
			'transaksi' => $this->transaksi->lihat(),
			'user' => $this->user->lihat(),
			
		];
		$this->view('dashboard', $data);
	}
}