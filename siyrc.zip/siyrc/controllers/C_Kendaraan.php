<?php 

class C_Kendaraan extends Controller{
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->merk = $this->model('M_Merk');
		$this->kendaraan = $this->model('M_Kendaraan');
	}

	public function index(){
		$data = [
			'aktif' => 'kendaraan',
			'judul' => 'Data Kendaraan',
			'data_merk' => $this->merk->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'no' => 1
		];
		$this->view('kendaraan/index', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('kendaraan');

		// proses upload
		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['gambar']['tmp_name'];
		$ekstensi = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['gambar']['error'];

		$img_name = $this->req->post('nama');
		$img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		if($error == 0){
			if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
			if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
				$data = [
					// ini untuk inputan datanya
					'id_merk' => $this->req->post('id_merk'),
					'nama' => $this->req->post('nama'),
					'warna' => $this->req->post('warna'),
					'jumlah_kursi' => $this->req->post('jumlah_kursi'),
					'no_polisi' => $this->req->post('no_polisi'),
					'tahun_beli' => $this->req->post('tahun_beli'),
					'kprice'=> $this->req->post('kprice'),
					'gambar' => $img_name . '.' . $ekstensi,
				];

				if($this->kendaraan->tambah($data)){
					setSession('success', 'Data berhasil ditambahkan!');
					redirect('kendaraan');
				} else {
					setSession('error', 'Data gagal ditambahkan!');
					redirect('kendaraan');
				}
			} else die('gagal upload foto');
		} else die('foto error');
	}

	public function detail($id){
		if(!isset($id) || $this->kendaraan->cek($id)->num_rows == 0) redirect('kendaraan');

		$data = [
			'aktif' => 'kendaraan',
			'judul' => 'Detail Kendaraan',
			'kendaraan' => $this->kendaraan->detail($id)->fetch_object(),
		];

		$this->view('kendaraan/detail', $data);
	}

	public function ubah($id){
		if(!isset($id) || $this->kendaraan->cek($id)->num_rows == 0) redirect('kendaraan');

		$data = [
			'aktif' => 'kendaraan',
			'judul' => 'Ubah Kendaraan',
			'kendaraan' => $this->kendaraan->lihat_id($id)->fetch_object(),
			'data_merk' => $this->merk->lihat(),
		];
		$this->view('kendaraan/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->kendaraan->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('kendaraan');

		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['gambar']['tmp_name'];
		$ekstensi = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['gambar']['error'];

		$img_name = $this->req->post('nama');
		$img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		$data = [
			'id_merk' => $this->req->post('id_merk'),
			'nama' => $this->req->post('nama'),
			'warna' => $this->req->post('warna'),
			'jumlah_kursi' => $this->req->post('jumlah_kursi'),
			'no_polisi' => $this->req->post('no_polisi'),
			'tahun_beli' => $this->req->post('tahun_beli'),
			'kprice'=> $this->req->post('kprice'),
			'gambar' => $img_name . '.' . $ekstensi,
		];

		$foto_sebelumnya = $this->kendaraan->detail($id)->fetch_object()->gambar;

		if($this->kendaraan->ubah($data, $id)){
			// unlink($upload_dir . $foto_sebelumnya) or die('gagal hapus foto lama');
			if($error == 0){
				if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
				if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
					setSession('success', 'Data berhasil diubah!');
					redirect('kendaraan');
				} else die('gagal upload foto');
			} else die('foto error');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('kendaraan');
		}
	}

	public function hapus($id = null){
		if(!isset($id) || $this->kendaraan->cek($id)->num_rows == 0) redirect('kendaraan');

		$gambar	= $this->kendaraan->detail($id)->fetch_object()->foto;
		// unlink(BASEPATH . DS . 'uploads' . DS . $fotor) or die('gagal hapus foto!');
		if($this->kendaraan->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('kendaraan');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('kendaraan');
		}
	}
}