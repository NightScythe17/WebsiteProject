<?php 

class C_Karyawan extends Controller{
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->level = $this->model('M_Level');
		$this->karyawan = $this->model('M_Karyawan');
	}

	public function index(){
		$data = [
			'aktif' => 'karyawan',
			'judul' => 'Data Karyawan',
			'data_level' => $this->level->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'no' => 1
		];
		$this->view('karyawan/index', $data);
	}

	public function detail($id){
		if(!isset($id) || $this->karyawan->cek($id)->num_rows == 0) redirect('karyawan');

		$data = [
			'aktif' => 'karyawan',
			'judul' => 'Detail Karyawan',
			'karyawan' => $this->karyawan->detail($id)->fetch_object(),
		];

		$this->view('karyawan/detail', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('karyawan');

		// proses upload
		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['foto']['tmp_name'];
		$ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['foto']['error'];

		$img_name = $this->req->post('nama');
		$img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		if($error == 0){
			if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
			if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
				$data = [
					'nama' => $this->req->post('nama'),
					'id_level' => $this->req->post('id_level'),
					'alamat' => $this->req->post('alamat'),
					'gender' => $this->req->post('gender'),
					'nip' => $this->req->post('nip'),
					'phone' => $this->req->post('phone'),
					'email' => $this->req->post('email'),
					'birth' => $this->req->post('birth'),
					'foto' => $img_name . '.' . $ekstensi,
				];

				if($this->karyawan->tambah($data)){
					setSession('success', 'Data berhasil ditambahkan!');
					redirect('karyawan');
				} else {
					setSession('error', 'Data gagal ditambahkan!');
					redirect('karyawan');
				}
			} else die('gagal upload gambar');
		} else die('gambar error');
	}

	public function hapus($id = null){
		if(!isset($id) || $this->karyawan->cek($id)->num_rows == 0) redirect('karyawan');

		$gambar	= $this->karyawan->detail($id)->fetch_object()->foto;

		unlink(BASEPATH . DS . 'uploads' . DS . $gambar) or die('gagal hapus gambar!');
		if($this->karyawan->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('karyawan');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('karyawan');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->karyawan->cek($id)->num_rows == 0) redirect('karyawan');

		$data = [
			'aktif' => 'karyawan',
			'judul' => 'Ubah karyawan',
			'karyawan' => $this->karyawan->lihat_id($id)->fetch_object(),
			'data_level' => $this->level->lihat(),
		];
		$this->view('karyawan/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->karyawan->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('karyawan');

		// proses upload
		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['foto']['tmp_name'];
		$ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['foto']['error'];

		$img_name = $this->req->post('nama');
		$img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		if($error == 0){
			if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
			if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
				$data = [
					'nama' => $this->req->post('nama'),
					'id_level' => $this->req->post('id_level'),
					'nip' => $this->req->post('nip'),
					'gender' => $this->req->post('gender'),
					'alamat' => $this->req->post('alamat'),
					'phone' => $this->req->post('phone'),
					'email' => $this->req->post('email'),
					'birth' => $this->req->post('birth'),
					'foto' => $img_name . '.' . $ekstensi,
				];

				if($this->karyawan->ubah($data, $id)){
					setSession('success', 'Data berhasil diubah!');
					redirect('karyawan');
				} else {
					setSession('error', 'Data gagal diubah!');
					redirect('karyawan');
				}
			} else die('gagal upload gambar');
		} else die('gambar error');

		
	}
}