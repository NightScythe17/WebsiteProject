<?php 

class C_Level extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->level = $this->model('M_Level');
	}

	public function index(){
		$data = [
			'aktif' => 'level',
			'judul' => 'Data Level',
			'data_level' => $this->level->lihat(),
			'no' => 1
		];
		$this->view('level/index', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('level');

		$level = $this->req->post('level');
		if($this->level->tambah($level)){
			setSession('success', 'Data berhasil ditambahkan!');
			redirect('level');
		} else {
			setSession('error', 'Data gagal ditambahkan!');
			redirect('level');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->level->cek($id)->num_rows == 0) redirect('level');

		$data = [
			'aktif' => 'level',
			'judul' => 'Ubah Level',
			'level' => $this->level->lihat_id($id)->fetch_object(),
		];
		$this->view('level/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->level->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('level');

		$level = $this->req->post('level');
		if($this->level->ubah($level, $id)){
			setSession('success', 'Data berhasil diubah!');
			redirect('level');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('level');
		}
	}

	public function hapus($id = null){
		if(!isset($id) || $this->level->cek($id)->num_rows == 0) redirect('level');

		if($this->level->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('level');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('level');
		}
	}
}