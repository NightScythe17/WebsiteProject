<?php 

if(!defined('BASEPATH')) echo "Tidak bisa langsung mengakses halaman ini!";

class C_Auth extends Controller{
	public function __construct(){
		$this->addFunction('url');
		if(isset($_SESSION['login'])) {
			header('Location: ' . base_url('dashboard'));
		}

		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->user = $this->model('M_User');
		$this->karyawan = $this->model('M_Karyawan');
	}
	
	public function index(){
		$this->view('login');
	}

	public function login(){
		if(!isset($_POST['login'])) redirect();
		else {
			$username = $this->req->post('username');
			$password = $this->req->post('password');

			$user = $this->user->cek_login($username);
			
			if($user->num_rows > 0){
				$user = $user->fetch_object();
				if(password_verify($password, $user->password)){
					setSession('login', [
						'auth' => true,
						'nama' => $user->nama,
						'username' => $user->username,
						'foto' => $user->foto,
						'waktu' => date('d M Y H:i:s')
					]);
					redirect('dashboard');
				} else {
					setSession('error', 'Password salah!');
					redirect();
				}
			} else {
				setSession('error', 'Username tidak ditemukan!');
				redirect();
			}
		}
	}

	public function logout(){
		unset($_SESSION['login']);
		redirect();
	}
}