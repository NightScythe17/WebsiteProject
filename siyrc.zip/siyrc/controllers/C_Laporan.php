<?php

class C_Laporan extends Controller{

    public function __construct(){
        $this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->transaksi = $this->model('M_Transaksi');
		$this->j_bayar = $this->model('M_Jenis_Bayar');
		$this->kendaraan = $this->model('M_Kendaraan');
		$this->penyewa = $this->model('M_Penyewa');
		$this->fasilitas = $this->model('M_Fasilitas');
		$this->karyawan = $this->model('M_Karyawan');
		$this->promosi = $this->model('M_Promosi');
		$this->denda = $this->model('M_Denda');
    }

    public function pendapatan(){
		$data = [
			'aktif' => 'Laporan',
			'judul' => 'Laporan Pendapatan',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		    $this->view('laporan/pendapatan', $data);
	}

	public function pendapatan_1(){
		$data = [
			'aktif' => 'Laporan',
			'judul' => 'Laporan Pendapatan',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_transaksi1' => $this->transaksi->cari_pend(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		    $this->view('laporan/pendapatan_1', $data);
	}

    public function kendaraan(){
		$data = [
			'aktif' => 'Laporan',
			'judul' => 'Laporan Kendaraan favorit',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/kendaraan', $data);
	}

    public function penyewa(){
		$data = [
			'aktif' => 'Laporan',
			'judul' => 'Laporan Jumlah Penyewa',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/penyewa', $data);
	}

    public function pendapatan_pdf(){
		$data = [
            'aktif' => 'Laporan',
			'judul' => 'Laporan Transaksi Pendapatan Yus Rent Car',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/pendapatan_pdf', $data);
	}

    public function penyewa_pdf(){
		$data = [
            'aktif' => 'Laporan',
			'judul' => 'Laporan Jumlah Penyewa Yus Rent Car',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/penyewa_pdf', $data);
	}

    public function kendaraan_pdf(){
		$data = [
            'aktif' => 'Laporan',
			'judul' => 'Laporan Kendaraan Favorit Yus Rent Car',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/kendaraan_pdf', $data);
	}

	public function pendapatan_excel(){
		$data = [
            'aktif' => 'Laporan',
			'judul' => 'Laporan Transaksi Pendapatan Yus Rent Car',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/pendapatan_excel', $data);
	}

    public function penyewa_excel(){
		$data = [
            'aktif' => 'Laporan',
			'judul' => 'Laporan Jumlah Penyewa Yus Rent Car',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/penyewa_excel', $data);
	}

    public function kendaraan_excel(){
		$data = [
            'aktif' => 'Laporan',
			'judul' => 'Laporan Kendaraan Favorit Yus Rent Car',
			'data_transaksi' => $this->transaksi->lihat(),
			'data_penyewa' => $this->penyewa->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_fasilitas' => $this->fasilitas->lihat(),
			'data_promosi' => $this->promosi->lihat(),
			'data_jenis_bayar' => $this->j_bayar->lihat(),
			'no' => 1
		];
		$this->view('laporan/kendaraan_excel', $data);
	}
    
}