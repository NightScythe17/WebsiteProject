<?php 

class C_Promosi extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->promosi = $this->model('M_Promosi');
	}

	public function index(){
		$data = [
			'aktif' => 'promosi',
			'judul' => 'Data Promosi',
			'data_promosi' => $this->promosi->lihat(),
			'no' => 1
		];
		$this->view('promosi/index', $data);
	}

    public function detail($id){
		if(!isset($id) || $this->promosi->cek($id)->num_rows == 0) redirect('promosi');

		$data = [
			'aktif' => 'promosi',
			'judul' => 'Detail Promosi',
			'promosi' => $this->promosi->detail($id)->fetch_object(),
		];

		$this->view('promosi/detail', $data);
	}
    
	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('promosi');

        $data = [
            'nama' => $this->req->post('nama'),
            'status' => $this->req->post('status'),
            'pprice' => $this->req->post('pprice'),
            'keterangan' => $this->req->post('keterangan'),
        ];
        
		if($this->promosi->tambah($data)){
			setSession('success', 'Data berhasil ditambahkan!');
			redirect('promosi');
		} else {
			setSession('error', 'Data gagal ditambahkan!');
			redirect('promosi');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->promosi->cek($id)->num_rows == 0) redirect('promosi');

		$data = [
			'aktif' => 'promosi',
			'judul' => 'Ubah Promosi',
			'promosi' => $this->promosi->lihat_id($id)->fetch_object(),
		];
		$this->view('promosi/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->promosi->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('promosi');

		$data = [
            'nama' => $this->req->post('nama'),
            'status' => $this->req->post('status'),
            'pprice' => $this->req->post('pprice'),
            'keterangan' => $this->req->post('keterangan'),
        ];
		if($this->promosi->ubah($data, $id)){
			setSession('success', 'Data berhasil diubah!');
			redirect('promosi');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('promosi');
		}
	}

	public function hapus($id = null){
		if(!isset($id) || $this->promosi->cek($id)->num_rows == 0) redirect('promosi');

		if($this->promosi->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('promosi');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('promosi');
		}
	}
}