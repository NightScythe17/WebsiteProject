<?php 

class C_Webpage extends Controller{
	public function __construct(){
		$this->addFunction('url');
		// if(!isset($_SESSION['login'])) {
		// 	$_SESSION['error'] = 'Anda harus masuk dulu!';
		// 	header('Location: ' . base_url());
		// }
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->penyewa = $this->model('M_Penyewa');
        $this->kendaraan = $this->model('M_Kendaraan');
	}


	public function dashboard(){
		
			$data['kendaraan'] = $this->kendaraan->weblihat(array());
		$this->view('webpage/dashboard', $data);
		
		
	}

    // public function datamobil(){

	// 	$data = [
	// 		'aktif' => 'penyewa',
	// 		'judul' => 'Data penyewa',
    //         'kendaraan' => $this->kendaraan->lihat()->fetch_object(),
	// 		'no' => 1
	// 	];
	// 	$this->view('webpage/datamobil', $data);
	// }

    public function detail($id){
		if(!isset($id) || $this->kendaraan->cek($id)->num_rows == 0) redirect('kendaraan');

		$data = [
			'aktif' => 'kendaraan',
			'judul' => 'Detail Kendaraan',
			'kendaraan' => $this->kendaraan->detail($id)->fetch_object(),
		];

		$this->view('kendaraan/detail', $data);
	}

}