<?php 

class C_Denda extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->denda = $this->model('M_Denda');
        $this->kendaraan = $this->model('M_Kendaraan');
	}

	public function index(){
		$data = [
			'aktif' => 'denda',
			'judul' => 'Data Denda',
			'data_kendaraan' => $this->kendaraan->lihat(),
			'data_denda' => $this->denda->lihat(),
			'no' => 1
		];
		$this->view('denda/index', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('denda');

        $data = [
            'type' => $this->req->post('type'),
            'id_kendaraan' => $this->req->post('id_kendaraan'),
            'dprice' => $this->req->post('dprice'),
        ];
		if($this->denda->tambah($data)){
			setSession('success', 'Data berhasil ditambahkan!');
			redirect('denda');
		} else {
			setSession('error', 'Data gagal ditambahkan!');
			redirect('denda');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->denda->cek($id)->num_rows == 0) redirect('denda');

		$data = [
			'aktif' => 'denda',
			'judul' => 'Ubah Denda',
			'denda' => $this->denda->lihat_id($id)->fetch_object(),
            'data_kendaraan' => $this->kendaraan->lihat(),
		];
		$this->view('denda/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->denda->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('denda');

        $data = [
            'type' => $this->req->post('type'),
            'id_kendaraan' => $this->req->post('id_kendaraan'),
            'dprice' => $this->req->post('dprice'),
        ];
		if($this->denda->ubah($data, $id)){
			setSession('success', 'Data berhasil diubah!');
			redirect('denda');
		} else {
			setSession('error', 'Data gagal diubah!');
			redirect('denda');
		}
	}

	public function hapus($id = null){
		if(!isset($id) || $this->denda->cek($id)->num_rows == 0) redirect('denda');

		if($this->denda->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('denda');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('denda');
		}
	}
}