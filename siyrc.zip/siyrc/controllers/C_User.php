<?php 

class C_User extends Controller {
	public function __construct(){
		$this->addFunction('url');
		if(!isset($_SESSION['login'])) {
			$_SESSION['error'] = 'Anda harus masuk dulu!';
			header('Location: ' . base_url());
		}
		
		$this->addFunction('web');
		$this->addFunction('session');
		$this->req = $this->library('Request');
		$this->user = $this->model('M_User');
		$this->karyawan = $this->model('M_Karyawan');
	}

	public function index(){
		$data = [
			'aktif' => 'user',
			'judul' => 'Data User',
			'data_user' => $this->user->lihat(),
			'data_karyawan' => $this->karyawan->lihat(),
			'no' => 1
		];
		$this->view('user/index', $data);
	}

	public function tambah(){
		if(!isset($_POST['tambah'])) redirect('user');

		if($_POST['password'] !== $_POST['password2']) {
			setSession('error', 'Password tidak sama!');
			redirect('user');
		} else {
			// proses upload
			$upload_dir = BASEPATH . DS . 'uploads' . DS;
			$asal = $_FILES['foto']['tmp_name'];
			$ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
			$error = $_FILES['foto']['error'];

			$img_name = $this->req->post('id_karyawan');
			$img_name = $this->req->post('id_karyawan');
			$img_name = strtolower($img_name);
			$img_name = str_replace(' ', '-', $img_name);
			$img_name = $img_name . '-' . time();

			if($error == 0){
				if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
				
				if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
					$data = [
						'id_karyawan' => $this->req->post('id_karyawan'),
						'username' => $this->req->post('username'),
						'password' => password_hash($this->req->post('password'), PASSWORD_DEFAULT),
						'foto' => $img_name . '.' . $ekstensi,
					];

					if($this->user->tambah($data)){
						setSession('success', 'Data berhasil ditambahkan!');
						redirect('user');
					} else {
						setSession('error', 'Data gagal ditambahkan!');
						redirect('user');
					}
				} else die('gagal upload gambar');
			} else die('gambar error');
		}
	}

	public function ubah($id){
		if(!isset($id) || $this->user->cek($id)->num_rows == 0) redirect('user');

		$data = [
			'aktif' => 'user',
			'judul' => 'Ubah User',
			'user' => $this->user->lihat_id($id)->fetch_object(),
			'data_karyawan' => $this->karyawan->lihat(),
		];
		$this->view('user/ubah', $data);
	}

	public function proses_ubah($id){
		if(!isset($id) || $this->user->cek($id)->num_rows == 0 || !isset($_POST['ubah'])) redirect('user');

		// proses upload
		$upload_dir = BASEPATH . DS . 'uploads' . DS;
		$asal = $_FILES['foto']['tmp_name'];
		$ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
		$error = $_FILES['foto']['error'];

		// $img_name = $this->req->post('nama');
		// $img_name = $this->req->post('nama');
		$img_name = strtolower($img_name);
		$img_name = str_replace(' ', '-', $img_name);
		$img_name = $img_name . '-' . time();

		if($error == 0){
			if(file_exists($upload_dir . $img_name . '.' . $ekstensi)) unlink($upload_dir . $img_name . '.' . $ekstensi);
			
			if(move_uploaded_file($asal, $upload_dir . $img_name . '.' . $ekstensi)){
				$data = [
						// 'id_karyawan' => $this->req->post('id_karyawan'),
						// 'username' => $this->req->post('username'),
						'password' => password_hash($this->req->post('password'), PASSWORD_DEFAULT),
						'foto' => $img_name . '.' . $ekstensi,
				];

				if($this->user->ubah($data, $id)){
					setSession('success', 'Data berhasil diubah!');
					redirect('user');
				} else {
					setSession('error', 'Data gagal diubah!');
					redirect('user');
				}
			} else die('gagal upload gambar');
		} else die('gambar error');
	}

	public function hapus($id = null){
		if(!isset($id) || $this->user->cek($id)->num_rows == 0) redirect('user');

		$gambar	= $this->user->detail($id)->fetch_object()->foto;

		unlink(BASEPATH . DS . 'uploads' . DS . $gambar) or die('gagal hapus gambar!');
		if($this->user->hapus($id)){
			setSession('success', 'Data berhasil dihapus!');
			redirect('user');
		} else {
			setSession('error', 'Data gagal dihapus!');
			redirect('user');
		}
	}

	public function detail($id){
		if(!isset($id) || $this->user->cek($id)->num_rows == 0) redirect('user');

		$data = [
			'aktif' => 'user',
			'judul' => 'Detail User',
			'user' => $this->user->detail($id)->fetch_object(),
		];

		$this->view('user/detail', $data);
	}
}