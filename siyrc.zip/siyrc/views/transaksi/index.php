<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title><?= APP_NAME ?> - <?= $judul ?></title>
	<link href="<?= base_url('sb-admin-2/') ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<link href="<?= base_url('sb-admin-2/') ?>/css/sb-admin-2.min.css" rel="stylesheet">
	<link href="<?= base_url('sb-admin-2/') ?>/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
	
</head>

<body id="page-top">
	<div id="wrapper">
	<?php partial('navbar', $aktif) ?>
	<!-- Content Wrapper -->
	<div id="content-wrapper" class="d-flex flex-column">
		<div id="content">
		<?php partial('topbar') ?>
			<div class="container-fluid">
				<div class="row"> 
					<div class="col-sm-12">
						<div class="clearfix">
							<div class="float-left">
								<h1 class="h3 mb-4 text-gray-800"><?= $judul ?></h1>
							</div>
							<!-- <div class="float-right">
								<a href="" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Tambah Data</a>
							</div> -->
						</div>
						<hr>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
						
					</div>
				</div>
				<div class="row">
					<div class="col-sm-4">
						<div class="card shadow">
							<div class="card-header">
								<h6 class="m-0 font-weight-bold text-primary">Tambah Data</h6>
							</div>
							<div class="card-body">
								<form method="POST" action="<?= base_url('transaksi/tambah') ?>" enctype="multipart/form-data">
								  	<div class="form-group">
									  
								  		<label for="id_penyewa">Nama Penyewa</label>
								  		<select name="id_penyewa" id="id_penyewa" class="form-control">
								  			<?php while($penyewa = $data_penyewa->fetch_object()) : ?>
												<option value="<?= $penyewa->id ?>"><?= $penyewa->nama ?></option>
								  			<?php endwhile; ?>
								  		</select>
											  
								  	</div>

									<div class="form-group">
								  		<label for="id_karyawan">Nama karyawan</label>
								  		<select name="id_karyawan" id="id_karyawan" class="form-control">
								  			<?php while($karyawan = $data_karyawan->fetch_object()) : ?>
												<option value="<?= $karyawan->id ?>"><?= $karyawan->nama ?></option>
								  			<?php endwhile; ?>
								  		</select>
								  	</div>

								  	<div class="form-group">
								  		<label for="id_kendaraan">Kendaraan</label>
								  		<select name="id_kendaraan" id="id_kendaraan" class="form-control">
								  			<?php while($kendaraan = $data_kendaraan->fetch_object()) : ?>
												<option value="<?= $kendaraan->id ?>"><?= $kendaraan->nama ?></option>
								  			<?php endwhile; ?>
								  		</select>
								  	</div>
									  <!-- <div class="form-group">
								  		<label for="test">Status</label>
										  <select  name="test" id="test" class="form-control">
								  			<option value="B">Belum Kembali</option>
								  		</select>
										  </div> -->
								  		<input type="hidden" name="test" id="test" value="B" class="form-control">
										  <input type="hidden" name="denda" id="denda" value="B" class="form-control">
										  <input type="hidden" name="kode_jual" id="kode_jual" value="IDJ000000" class="form-control">
									  
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="id_fasilitas">Fasilitas</label>
												<select name="id_fasilitas" id="id_fasilitas" class="form-control">
													<?php while($fasilitas = $data_fasilitas->fetch_object()) : ?>
														<option value="<?= $fasilitas->id ?>"><?= $fasilitas->nama ?></option>
													<?php endwhile; ?>
												</select>
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group">
												<label for="id_promosi">Promosi</label>
												<select name="id_promosi" id="id_promosi" class="form-control">
													<?php while($promosi = $data_promosi->fetch_object()) : ?>
														<option value="<?= $promosi->id ?>"><?= $promosi->nama ?></option>
													<?php endwhile; ?>
												</select>
											</div>
										</div>
									</div>

								  			<div class="form-group">
										  		<label for="id_jenis_bayar">Jenis Bayar</label>
										  		<select name="id_jenis_bayar" id="id_jenis_bayar" class="form-control">
										  			<?php while($jenis_bayar = $data_jenis_bayar->fetch_object()) : ?>
														<option value="<?= $jenis_bayar->id ?>"><?= $jenis_bayar->jenis_bayar ?></option>
										  			<?php endwhile; ?>
										  		</select>
										  	</div>
								  		
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
										  		<label for="tgl_pinjam">Tanggal Pinjam</label>
										  		<input type="date" name="tgl_pinjam" id="tgl_pinjam" required="required" autocomplete="off" class="form-control">
										  	</div>
									  	</div>
										<div class="col-md-6">
											<div class="form-group">
										  		<label for="tgl_kembali">Tanggal Kembali</label>
										  		<input type="date" name="tgl_kembali" id="tgl_kembali" required="required" autocomplete="off" class="form-control">
										  	</div>
									  	</div>
									</div>
									
								  	<div class="form-group">
										<button type="submit" class="btn btn-sm btn-success" name="tambah"><i class="fa fa-plus"></i> Tambah</button>
										<button type="reset" class="btn btn-sm btn-danger"><i class="fa fa-times"></i> Batal</button>
								  	</div>
								</form>
							</div>
						</div>
					</div>

					<div class="col-sm-8">
						<div class="card shadow">
							<div class="card-header">
								<h6 class="m-0 font-weight-bold text-primary">Daftar Transaksi</h6>
							</div>
							<div class="card-body">
								<?php if(checkSession('success')): ?>
									<div class="alert alert-success alert-dismissible fade show" role="alert">
							  			<?= getSession('success', true) ?>
							  			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							    			<span aria-hidden="true">&times;</span>
							  			</button>
									</div>
								<?php elseif(checkSession('error')): ?>
									<div class="alert alert-danger alert-dismissible fade show" role="alert">
							  			<?= getSession('error', true) ?>
							  			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							    			<span aria-hidden="true">&times;</span>
							  			</button>
									</div>
								<?php endif ?>

								<table class="table table-bordered" id="dataTable" width="" cellspacing="0">
	                  				<thead>
	                    				<tr>
	                    					
											<th>Kode</th>
	                    					<th>Penyewa</th>
											<th>Karyawan</th>
	                    					<th>Kendaraan</th>
											<th>Tanggal Pinjam</th>
	                    					<th>Total Transaksi</th>
	                    					<th>Aksi</th>
	                    				</tr>
	                 				</thead>
	                  				<tfoot>
	                    				<tr>
	                    					
											<th>Kode</th>
	                    					<th>Penyewa</th>
											<th>Karyawan</th>
	                    					<th>Kendaraan</th>
											<th>Tanggal Pinjam</th>
	                    					<th>Total Transaksi</th>
	                    					<th>Aksi</th>
	                    				</tr>
	                  				</tfoot>
	                 				<tbody>
										<?php 
										while($transaksi = $data_transaksi->fetch_object()) : ?>
											<tr>
												
												<td><?= $transaksi->kode_jual ?><?= $transaksi->id ?></td>
												<td><?= $transaksi->nama_penyewa ?></td>
												<td><?= $transaksi->nama_karyawan ?></td>
												<td><?= $transaksi->nama_kendaraan?><br><?= $transaksi->nopol?></td>
												<td><?= $transaksi->tgl_pinjam ?></td>
												<?php
													$a = $transaksi->tgl_pinjam;
													$b = $transaksi->tgl_kembali;
													$x = strtotime($a);
													$y = strtotime($b);
													$jmlhari = abs(($x-$y)/(60*60*24));
												?>
												<?php
													$harga = $transaksi->k_price + $transaksi->f_price - $transaksi->p_price;
												?>

												<td>Rp. <?= number_format($harga * $jmlhari, 2, ',', '.')?></td>
												<td>
													<a href="<?= base_url('transaksi/ubah/' . $transaksi->id) ?>" class="btn btn-sm btn-info mb-2"><i class="fa fa-pen"></i> Ubah</a><br>
													<a href="<?= base_url('transaksi/detail/' . $transaksi->id) ?>" class="btn btn-sm btn-warning mb-2"><i class="fa fa-eye"></i> Detail</a><br>
	                 								<a href="<?= base_url('transaksi/hapus/' . $transaksi->id) ?>" class="btn btn-sm btn-danger" onclick="return confirm('apakah anda yakin?')"><i class="fa fa-trash"></i> Hapus</a>
												</td>
											</tr>
										<?php endwhile; ?>
									</tbody>
              					</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php partial('footer') ?>
	</div>
	</div>

	<a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	</a>

	<script src="<?= base_url('sb-admin-2/') ?>/vendor/jquery/jquery.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/vendor/jquery-easing/jquery.easing.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/js/sb-admin-2.min.js"></script>

	<script src="<?= base_url('sb-admin-2/') ?>/vendor/datatables/jquery.dataTables.min.js"></script>
  	<script src="<?= base_url('sb-admin-2/') ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/js/demo/datatables-demo.js"></script>

	
	
</body>

</html>
