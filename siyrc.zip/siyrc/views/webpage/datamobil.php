<?php partial('pheader') ?>
    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4>Catalog</h4>
                <h2>Silahkan Pilih Mobil kami yang tersedia!</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->


    <section class="blog-posts grid-system">
      <div class="container">
        <div class="all-blog-posts">
          <div class="row">
                    <!-- single car -->
                    <?php foreach($kendaraan as $k) : ?>
                      <div class="col-md-4 col-sm-6 grid-stn">
                        <div class="blog-post">
                            <div class="blog-thumb">
                            <img src="<?php echo base_url('uploads/' . $k['gambar']) ?>" alt="<?= $k['nama'] ?>" weight="800px" height="400PX"></div>
                              <div class="down-content">
                                <h4><?= $k['nama'] ?></h4></a>
                                <p>
                                    <i class="fa fa-user" title="passegengers"></i> <?= $k['jumlah_kursi'] ?> &nbsp;&nbsp;&nbsp;
                                    <i class="fa fa-dollar" title="price"></i> Rp. <?= number_format($k['kprice'],2,',','.')?> /Hari &nbsp;&nbsp;&nbsp;
                                </p>
                                <div class="post-options">
                                    <div class="row">
                                      <div class="col-lg-12">
                                          <ul class="post-tags">
                                          <li><i class="fa fa-bullseye"></i></li>
                                          <li><a href="#" data-toggle="modal" data-target="#exampleModal">Book Now</a></li>
                                          </ul>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      </div>
                    <?php endforeach ?>
                    <!-- end single car -->
          </div>
        </div>
      </div>
    </section>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Book Now</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <?php foreach($detail as $dt) : ?>
            <div class="contact-us">
            <div class="contact-form">
            <form method="POST" action="<?= base_url('transaksi/tambah') ?>" enctype="multipart/form-data">
              <!-- <form action="#" id="contact"> -->
                  <div class="row">
                       <div class="col-md-6">
                          <fieldset>
                            <input type="text"  id="id_penyewa" name="id_penyewa" class="form-control" placeholder="Nama Lengkap" required="">
                          </fieldset>
                       </div>

                       <div class="col-md-6">
                          <fieldset>
                            <input type="text" class="form-control" placeholder="Return location" required="">
                          </fieldset>
                       </div>
                  </div>

                  <div class="row">
                       <div class="col-md-6">
                          <fieldset>
                            <input type="text" class="form-control" placeholder="Pick-up date/time" required="">
                          </fieldset>
                       </div>

                       <div class="col-md-6">
                          <fieldset>
                            <input type="text" class="form-control" placeholder="Return date/time" required="">
                          </fieldset>
                       </div>
                  </div>
                  <input type="text" class="form-control" placeholder="Enter full name" required="">

                  <div class="row">
                       <div class="col-md-6">
                          <fieldset>
                            <input type="text" class="form-control" placeholder="Enter email address" required="">
                          </fieldset>
                       </div>

                       <div class="col-md-6">
                          <fieldset>
                            <input type="text" class="form-control" placeholder="Enter phone" required="">
                          </fieldset>
                       </div>
                  </div>
                  <div class="row">
                       <div class="col-md-6">
                          <fieldset>
                            <input type="text" class="form-control" placeholder="Enter email address" required="">
                          </fieldset>
                       </div>

                       <div class="col-md-6">
                          <fieldset>
                          <input type="hidden" name="id_kendaraan" value="<?= $transa->id ?>"><?= $karyawan->nama ?>">
                            <input type="text" class="form-control" placeholder="Enter phone" required="">
                          </fieldset>
                       </div>
                  </div>
              </form>
           </div>
           </div>
           <?php endforeach?>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" name="tambah"><i ></i> Bok Now</button>
            <!-- <button type="button" class="btn btn-primary">Book Now</button> -->
          </div>
        </div>
      </div>
    </div>
    <?php partial('pfooter') ?>

    