<?php partial('pheader') ?>
  <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text">
      <div class="container-fluid">
        <div class="owl-banner owl-carousel">
          <?php foreach($kendaraan as $k) : ?>  
            <div class="item">
            <img src="<?php echo base_url('uploads/' . $k['gambar']) ?>" alt="<?= $k['nama'] ?>" weight="800px" height="400PX">
              <div class="item-content">
                <div class="main-content">
                  <div class="meta-category">
                    <span>
                    <i class="fa fa-car" ></i><?= $k['nama'] ?> &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-user" title="passegengers"></i> <?= $k['jumlah_kursi'] ?> &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-dollar" title="price"></i> Rp. <?= number_format($k['kprice'],2,',','.')?> /Hari &nbsp;&nbsp;&nbsp;
                    </span>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach ?>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4>Tentang Kami</h4>
                <h2>Silahkan Cek Catalog!</h2>
                <h2>Tersedia banyak mobil untuk disewakan!</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->


    <section class="about-us">
      <div class="container">
      	
        <div class="row">
          <div class="col-lg-12">
            <img src="assets/upload/jazz-1620215978.jpg" alt="">
            </div>
        </div>
        </div>
    </section>
    <?php partial('pfooter') ?>
    