<ul class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('dashboard') ?>">
        <div class="sidebar-brand-icon">
            <i class="fas fa-car"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Yus Rent Car</div>
    </a>

    <hr class="sidebar-divider my-0">

    <li class="nav-item <?= $data == 'dashboard' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('dashboard') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Karyawan
    </div>

    <li class="nav-item <?= $data == 'karyawan' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('karyawan') ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Data Karyawan</span>
        </a>
    </li>
    <li class="nav-item <?= $data == 'level' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('level') ?>">
            <i class="fas fa-user-friends"></i>
            <span>Data Level</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Penyewa
    </div>

    <li class="nav-item <?= $data == 'penyewa' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('penyewa') ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Data Penyewa</span>
        </a>
    </li>
    <li class="nav-item <?= $data == 'jenis_bayar' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('jenis_bayar') ?>">
            <i class="fas fa-fw fa-dollar-sign"></i>
            <span>Data Jenis Bayar</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Kendaraan
    </div>
    
    <li class="nav-item <?= $data == 'merk' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('merk') ?>">
            <i class="fas fa-fw fa-columns"></i>
            <span>Data Merk</span>
        </a>
    </li>
    <li class="nav-item <?= $data == 'kendaraan' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('kendaraan') ?>">
            <i class="fas fa-fw fa-car-alt"></i>
            <span>Data Kendaraan</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Denda
    </div>

    <li class="nav-item <?= $data == 'denda' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('denda') ?>">
            <i class="fas fa-fw fa-dollar-sign"></i>
            <span>Data Denda</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Fasilitas
    </div>

    <li class="nav-item <?= $data == 'fasilitas' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('fasilitas') ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Data Fasilitas</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Promosi
    </div>

    <li class="nav-item <?= $data == 'promosi' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('promosi') ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Data Promosi</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master Transaksi
    </div>

    <li class="nav-item <?= $data == 'transaksi' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('transaksi') ?>">
            <i class="fas fa-fw fa-receipt"></i>
            <span>Data Transaksi</span>
        </a>
    </li>
    <li class="nav-item <?= $data == 'pengembalian' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('transaksi/pengembalian') ?>">
            <i class="fas fa-fw fa-receipt"></i>
            <span>Data Pengembalian</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Laporan
    </div>

    <li class="nav-item <?= $data == 'laporan' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('laporan/pendapatan') ?>">
            <i class="fas fa-fw fa-receipt"></i>
            <span>Laporan Pendapatan</span>
        </a>
    </li>
    <li class="nav-item <?= $data == 'laporan' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('laporan/kendaraan') ?>">
            <i class="fas fa-fw fa-receipt"></i>
            <span>Laporan Kendaraan</span>
        </a>
    </li>
    <li class="nav-item <?= $data == 'laporan' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('laporan/penyewa') ?>">
            <i class="fas fa-fw fa-receipt"></i>
            <span>Laporan Penyewa</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Master User
    </div>

    <li class="nav-item <?= $data == 'user' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('user') ?>">
            <i class="fas fa-fw fa-cog"></i>
            <span>Manajemen User</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>