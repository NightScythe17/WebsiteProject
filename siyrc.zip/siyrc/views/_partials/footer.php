<footer class="sticky-footer bg-white">
	<div class="container my-auto">
	    <div class="copyright text-center my-auto">
	    <span>
	    <a href="https://www.linkedin.com/in/brayen-billion/" target="_blank">Brayen Billion</a> &copy; Yus Rent Car <?= date('Y') ?></span>
	    </div>
	</div>
</footer>