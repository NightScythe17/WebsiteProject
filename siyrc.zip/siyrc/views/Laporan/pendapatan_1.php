<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title><?= APP_NAME ?> - <?= $judul ?></title>
	<link href="<?= base_url('sb-admin-2/') ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<link href="<?= base_url('sb-admin-2/') ?>/css/sb-admin-2.min.css" rel="stylesheet">
	<link href="<?= base_url('sb-admin-2/') ?>/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

	
</head>

<body id="page-top">
	<div id="wrapper">
	<?php partial('navbar', $aktif) ?>
	<!-- Content Wrapper -->
	<div id="content-wrapper" class="d-flex flex-column">
		<div id="content">
            <?php partial('topbar') ?>
                <div class="container-fluid">
                    <div class="row"> 
                        <div class="col-sm-12">
                            <div class="clearfix">
                                <div class="float-left">
                                    <h1 class="h3 mb-4 text-gray-800"><?= $judul ?></h1>
                                </div>
                                
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
					<div class="col-sm-4">
                        <form method="POST" >
                         <div class="form-group">
                             <label>Dari Tanggal</label>
                            <input type="date" name="date1" id="date1" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Dari Tanggal</label>
                        <input type="date" name="date2" id="date2" class="form-control">
                    </div>
                    <hr>
                    <input type="submit" name="filter" class="btn btn-sm btn-success" value="Tampil"><i class="fas fa-eye"></i>
                </form>
                <hr>
                    <div class="btn-group">
                        <a class="btn btn-sm btn-success" target="_blank" href="<?= base_url('laporan/pendapatan_pdf') ?>" ><i class="far fa-file-pdf"></i>Export PDF</a>
                    </div>
                    <div class="btn-group">
                    <a class="btn btn-sm btn-success" target="_blank" href="<?= base_url('laporan/pendapatan_excel') ?>" ><i class="far fa-file-excel"></i> Excel</a>
                    </div>
                </div>
				</div>
                <hr>
                <table class="table table-bordered" id="dataTable" width="" cellspacing="0">
	                  				<thead>
	                    				<tr>
	                    					<th>No</th>
											<th>Kode</th>
                                            <th>Penyewa</th>
                                            <th>Karyawan</th>
	                    					<th>Kendaraan</th>
											<th>Tanggal Pinjam</th>
                                            <th>Tanggal Kembali</th>
	                    					<th>Total Transaksi</th>
	                    				</tr>
	                 				</thead>
	                  				<tfoot>
	                    				<tr>
	                    					<th>No</th>
											<th>Kode</th>
                                            <th>Penyewa</th>
                                            <th>Karyawan</th>
	                    					<th>Kendaraan</th>
											<th>Tanggal Pinjam</th>
                                            <th>Tanggal Kembali</th>
	                    					<th>Total Transaksi</th>
	                    				</tr>
	                  				</tfoot>
	                 				<tbody>
                                        <?php 
                                            if(isset($_POST["filter"])){
                                                $dt1 = $_POST["date1"];
                                                $dt2 = $_POST["date2"];
                                                $no = 1;
 
                                                while($laporan = )
                                            }
                                        ?>
									</tbody>
              					</table>
                </div>
        </div>

        <?php partial('footer') ?>
    </div>
    </div>

    <script src="<?= base_url('sb-admin-2/') ?>/vendor/jquery/jquery.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/vendor/jquery-easing/jquery.easing.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/js/sb-admin-2.min.js"></script>

	<script src="<?= base_url('sb-admin-2/') ?>/vendor/datatables/jquery.dataTables.min.js"></script>
  	<script src="<?= base_url('sb-admin-2/') ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
	<script src="<?= base_url('sb-admin-2/') ?>/js/demo/datatables-demo.js"></script>
</body>

</html>
<!-- <td><?php echo $no++;?></td>
                                                <td><?php echo $data['kode_jual'];?><?php echo $data['id'];?></td>
                                                <td><?php echo $data['nama_penyewa'];?></td>
                                                <td><?php echo $data['nama_karyawan'];?></td>
                                                <td><?php echo $data['Nama_kendaraan'];?></td>
                                                <td><?php echo $data['tgl_pinjam'];?></td>
                                                <td><?php echo $data['tgl_kembali'];?></td> -->