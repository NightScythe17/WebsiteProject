<h3 style="text-align: center"><?= $judul ?></h3>

<table class="table table-bordered table-striped mt-2" border="1" align="center">
<thead>
	                    				<tr>
	                    					<th>No</th>
											<th>Kode</th>
	                    					<th>Kendaraan</th>
											<th>Tanggal Pinjam</th>
	                    					<th>Tanggal Kembali</th>
	                    				</tr>
	                 				</thead>
	                  				<tfoot>
	                    				<tr>
	                    					<th>No</th>
											<th>Kode</th>
	                    					<th>Kendaraan</th>
											<th>Tanggal Pinjam</th>
	                    					<th>Tanggal Kembali</th>
	                    				</tr>
	                  				</tfoot>
	                 				<tbody>
										<?php 
										while($transaksi = $data_transaksi->fetch_object()) : ?>
											<tr>
												<td><?= $no++ ?></td>
												<td><?= $transaksi->kode_jual ?><?= $transaksi->id ?></td>
												<td><?= $transaksi->nama_kendaraan?><br><?= $transaksi->nopol?></td>
												<td><?= $transaksi->tgl_pinjam ?></td>
                                                <td><?= $transaksi->tgl_kembali ?></td>
												
											</tr>
										<?php endwhile; ?>
									</tbody>
                                                    
									
              					</table>


                                  <script type="text/javascript">
                                  window.print();
                                
                                </script>