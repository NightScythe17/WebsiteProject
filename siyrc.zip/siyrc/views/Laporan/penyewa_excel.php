<h3 style="text-align: center"><?= $judul ?></h3>
<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data jumlahpenyewa.xls");
	?>
<table class="table table-bordered table-striped mt-2" border="1" align="center">
<thead>
	                    				<tr>
	                    					<th>No</th>
											<th>Kode</th>
	                    					<th>Penyewa</th>
											<th>Tanggal Pinjam</th>
                                            <th>Tanggal Kembali</th>
	                    					<th>Total Transaksi</th>
	                    				</tr>
	                 				</thead>
	                  				<tfoot>
	                    				<tr>
	                    					<th>No</th>
											<th>Kode</th>
	                    					<th>Penyewa</th>
											<th>Tanggal Pinjam</th>
                                            <th>Tanggal Kembali</th>
	                    					<th>Total Transaksi</th>
	                    				</tr>
	                  				</tfoot>
	                 				<tbody>
										<?php 
										while($transaksi = $data_transaksi->fetch_object()) : ?>
											<tr>
												<td><?= $no++ ?></td>
												<td><?= $transaksi->kode_jual ?><?= $transaksi->id ?></td>
												<td><?= $transaksi->nama_penyewa ?></td>
												<td><?= $transaksi->tgl_pinjam ?></td>
                                                <td><?= $transaksi->tgl_kembali ?></td>
												<?php
													$a = $transaksi->tgl_pinjam;
													$b = $transaksi->tgl_kembali;
													$x = strtotime($a);
													$y = strtotime($b);
													$jmlhari = abs(($x-$y)/(60*60*24));
												?>
												<?php
													$harga = $transaksi->k_price + $transaksi->f_price - $transaksi->p_price;
												?>
                                                <?php
												$a = $transaksi->tgl_kembali;
												$b = $transaksi->tgl_kembalikan;
												$c = $transaksi->k_price;
												$x = strtotime($a);
												$y = strtotime($b);
												$jmlhari1 = abs(($x-$y)/(60*60*24));
												if($jmlhari1 >= 1){
													$denda_ter = $jmlhari1 * ($c * 0.10);}
													else $denda_ter = 0;
												?>
												<?php
												$a = $transaksi->denda;
												$b = $transaksi->k_price;
												if($a == "A" ){
													$denda_ker = $b * 3;
												}
													else $denda_ker = 0;
												?>
                                                <?php
												$a = $transaksi->denda;
												$b = $transaksi->k_price;
												if($a == "A" ){
													$denda_ker = $b * 3;
												}
													else $denda_ker = 0;
												?>
												<?php
												$tdenda = $denda_ter + $denda_ker;
												?>

												<td>Rp. <?= number_format(($harga * $jmlhari) + $tdenda, 2, ',', '.')?></td>
												
											</tr>
										<?php endwhile; ?>
									</tbody>
                                                    
									
              					</table>


                                  <script type="text/javascript">
                                  window.print();
                                
                                </script>