<?php partial('pheader') ?>
  <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text">
      <div class="container-fluid">
        <div class="owl-banner owl-carousel">
          <div class="item">
            <img src="assets/images/product-1-720x480.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span>
                    <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-cog"></i> A
                  </span>
                </div>
                <a href="fleet.html"><h4>Lorem ipsum dolor sit amet.</h4></a>
                
              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/product-2-720x480.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span>
                    <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-cog"></i> A
                  </span>
                </div>
                <a href="fleet.html"><h4>Lorem ipsum dolor sit amet.</h4></a>
               
              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/product-3-720x480.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span>
                    <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-cog"></i> A
                  </span>
                </div>
                <a href="fleet.html"><h4>Lorem ipsum dolor sit amet.</h4></a>
              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/product-4-720x480.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span>
                    <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-cog"></i> A
                  </span>
                </div>
                <a href="fleet.html"><h4>Lorem ipsum dolor sit amet.</h4></a>
                <ul class="post-info">
                  <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus minima error doloribus aliquid, optio dignissimos sint earum! Eos, blanditiis repudiandae.</li>
                </ul>
              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/product-5-720x480.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span>
                    <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-cog"></i> A
                  </span>
                </div>
                <a href="fleet.html"><h4>Lorem ipsum dolor sit amet.</h4></a>
                <ul class="post-info">
                  <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus minima error doloribus aliquid, optio dignissimos sint earum! Eos, blanditiis repudiandae.</li>
                </ul>
              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/product-6-720x480.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span>
                    <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                    <i class="fa fa-cog"></i> A
                  </span>
                </div>
                <a href="fleet.html"><h4>Lorem ipsum dolor sit amet.</h4></a>
                <ul class="post-info">
                  <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus minima error doloribus aliquid, optio dignissimos sint earum! Eos, blanditiis repudiandae.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <section class="blog-posts grid-system">
      <div class="container">
        <div class="all-blog-posts">
          <h2 class="text-center">Catalog</h2>
          <br>
          <div class="row">
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/offer-1-720x480.jpg" alt="">
                </div>
                <div class="down-content">
                  <strong>from</strong> <span> $120</span> <strong>per weekend</strong>
                  <a href="offers.html"><h4>Lorem ipsum dolor sit amet, consectetur</h4></a>
                  <p>Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend.</p>
                  <div class="post-options">
                    <div class="row">
                      <div class="col-lg-12">
                        <ul class="post-tags">
                          <li><i class="fa fa-bullseye"></i></li>
                          <li><a href="offers.html">View More</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/offer-2-720x480.jpg" alt="">
                </div>
                <div class="down-content">
                  <strong>from</strong> <span> $120</span> <strong>per weekend</strong>
                  <a href="offers.html"><h4>Lorem ipsum dolor sit amet, consectetur</h4></a>
                  <p>Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend.</p>
                  <div class="post-options">
                    <div class="row">
                      <div class="col-lg-12">
                        <ul class="post-tags">
                          <li><i class="fa fa-bullseye"></i></li>
                          <li><a href="offers.html">View More</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/offer-3-720x480.jpg" alt="">
                </div>
                <div class="down-content">
                  <strong>from</strong> <span> $120</span> <strong>per weekend</strong>
                  <a href="offers.html"><h4>Lorem ipsum dolor sit amet, consectetur</h4></a>
                  <p>Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend.</p>
                  <div class="post-options">
                    <div class="row">
                      <div class="col-lg-12">
                        <ul class="post-tags">
                          <li><i class="fa fa-bullseye"></i></li>
                          <li><a href="offers.html">View More</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php partial('pfooter') ?>
    