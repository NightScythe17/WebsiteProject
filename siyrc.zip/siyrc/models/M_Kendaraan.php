<?php 

class M_Kendaraan extends Model {
	public function lihat(){
		$query = $this->setQuery('SELECT nama, no_polisi, tbl_merk.merk AS merk, jumlah_kursi, tbl_kendaraan.id AS id FROM tbl_kendaraan INNER JOIN tbl_merk ON tbl_merk.id = tbl_kendaraan.id_merk');
		$query = $this->execute();
		return $query;
	}

	public function weblihat($where = array()){
		$query = $this->setQuery("SELECT *, tbl_kendaraan.id AS id_kendaraan, tbl_kendaraan.id_merk AS id_merk FROM tbl_kendaraan INNER JOIN tbl_merk ON tbl_merk.id = tbl_kendaraan.id_merk where tbl_kendaraan.id");
		$query = $this->execute();
		return $query;
	}

	public function fulllihat(){
		$query = $this->setQuery("SELECT *, tbl_kendaraan.id AS id_kendaraan, tbl_kendaraan.id_merk AS id_merk FROM tbl_kendaraan INNER JOIN tbl_merk ON tbl_merk.id = tbl_kendaraan.id_merk");
		$query = $this->execute();
		return $query;
	}

	public function get_mobil($where = array()){
		$this->db->from('tbl_kendaraan');
		$this->db->join('merk', 'tbl_kendaraan.id_merk = merk.id', 'LEFT');
		return $this->db->get()->result();
	}

	public function tambah($data){
		$query = $this->insert('tbl_kendaraan', $data);
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->setQuery("SELECT *, tbl_kendaraan.id AS id_kendaraan, tbl_kendaraan.id_merk AS id_merk FROM tbl_kendaraan INNER JOIN tbl_merk ON tbl_merk.id = tbl_kendaraan.id_merk where tbl_kendaraan.id = $id");
		$query = $this->execute();
		return $query;
	}

	public function ubah($data, $id){
		$query = $this->update('tbl_kendaraan', $data, ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_kendaraan', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function detail($id){
		$query = $this->setQuery("SELECT *, tbl_kendaraan.id AS id_kendaraan, tbl_kendaraan.id_merk AS id_merk FROM tbl_kendaraan INNER JOIN tbl_merk ON tbl_merk.id = tbl_kendaraan.id_merk where tbl_kendaraan.id = $id");
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_kendaraan', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}
}