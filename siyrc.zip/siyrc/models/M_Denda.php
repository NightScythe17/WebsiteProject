<?php 

class M_Denda extends Model {
	public function lihat(){
		$query = $this->setQuery('SELECT *, tbl_kendaraan.nama AS id_kendaraan, tbl_denda.id AS id FROM tbl_denda INNER JOIN tbl_kendaraan ON tbl_kendaraan.id = tbl_denda.id_kendaraan');
		$query = $this->execute();
		return $query;
	}

	public function tambah($data){
		$query = $this->insert('tbl_denda', $data);
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->get_where('tbl_denda', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function ubah($data, $id){
		$query = $this->update('tbl_denda', $data, ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_denda', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function detail($id){
		$query = $this->setQuery("SELECT *, tbl_denda.id AS id_denda, tbl_denda.id_kendaraan AS id_kendaraan FROM tbl_denda INNER JOIN tbl_kendaraan ON tbl_kendaraan.id = tbl_denda.id_kendaraan where tbl_denda.id = $id");
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_denda', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}
}