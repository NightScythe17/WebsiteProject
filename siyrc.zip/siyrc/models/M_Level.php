<?php 

class M_Level extends Model{
	public function tambah($data){
		$query = $this->insert('tbl_level', ['level' => $data]);
		$query = $this->execute();
		return $query;
	}

	public function lihat(){
		$query = $this->get('tbl_level');
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->get_where('tbl_level', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function ubah($level, $id){
		$query = $this->update('tbl_level', ['level' => $level], ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_level', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_level', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}
}