<?php 

class M_User extends Model {
	public function lihat(){
		$query = $this->setQuery('SELECT nama, username, tbl_karyawan.nama AS karyawan,  tbl_user.id AS id FROM tbl_user INNER JOIN tbl_karyawan ON tbl_karyawan.id = tbl_user.id_karyawan');
		// $query = $this->get('tbl_user', ['nama', 'username', 'id']);
		$query = $this->execute();
		return $query;
	}

	public function tambah($data){
		$query = $this->insert('tbl_user', $data);
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->setQuery("SELECT *, tbl_user.id AS id_user, tbl_user.id_karyawan AS id_karyawan FROM tbl_user INNER JOIN tbl_karyawan ON tbl_karyawan.id = tbl_user.id_karyawan where tbl_user.id = $id");
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_user', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function ubah($data, $id){
		$query = $this->update('tbl_user', $data, ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek_login($username){
		$query = $this->get_where('tbl_user', ['username' => $username]);
		$query = $this->execute();
		return $query;
	}

	public function detail($id){
		$query = $this->setQuery("SELECT *, tbl_user.id AS id_user, tbl_user.id_karyawan AS id_karyawan FROM tbl_user INNER JOIN tbl_karyawan ON tbl_karyawan.id = tbl_user.id_karyawan where tbl_user.id = $id");
		// $query = $this->get_where('tbl_user', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_user', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}
}