<?php 

class M_Fasilitas extends Model{
	public function tambah($data){
		$query = $this->insert('tbl_fasilitas', $data);
		$query = $this->execute();
		return $query;
	}

	public function lihat(){
		$query = $this->get('tbl_fasilitas');
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->get_where('tbl_fasilitas', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function ubah($data, $id){
		$query = $this->update('tbl_fasilitas', $data, ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_fasilitas', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_fasilitas', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}
}