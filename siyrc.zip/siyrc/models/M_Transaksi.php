<?php 

class M_Transaksi extends Model{
	public function tambah($data){
		$query = $this->insert('tbl_transaksi', $data);
		$query = $this->execute();
		return $query;
	}

	public function lihat(){
		$query = $this->setQuery("SELECT *, tbl_transaksi.id, tbl_penyewa.nama AS nama_penyewa, tbl_karyawan.nama AS nama_karyawan, tbl_kendaraan.no_polisi AS nopol, 
		tbl_kendaraan.nama AS nama_kendaraan, tbl_kendaraan.kprice AS k_price,  tbl_fasilitas.nama AS nama_fasilitas, tbl_fasilitas.fprice AS f_price, 
		tbl_promosi.nama AS nama_promosi, tbl_promosi.pprice AS p_price, tbl_jenis_bayar.jenis_bayar
		FROM tbl_transaksi 
		INNER JOIN tbl_penyewa ON tbl_transaksi.id_penyewa = tbl_penyewa.id INNER JOIN tbl_karyawan ON tbl_transaksi.id_karyawan = tbl_karyawan.id 
		INNER JOIN tbl_kendaraan ON tbl_transaksi.id_kendaraan = tbl_kendaraan.id INNER JOIN tbl_fasilitas ON tbl_transaksi.id_fasilitas = tbl_fasilitas.id 
		INNER JOIN tbl_promosi ON tbl_transaksi.id_promosi = tbl_promosi.id INNER JOIN tbl_jenis_bayar ON tbl_transaksi.id_jenis_bayar = tbl_jenis_bayar.id
		");
		$query = $this->execute();
		return $query;
	}

	public function wlihat(){
		$query = $this->setQuery("SELECT *, tbl_transaksi.id, tbl_penyewa.nama AS nama_penyewa, tbl_karyawan.nama AS nama_karyawan, tbl_kendaraan.no_polisi AS nopol, 
		tbl_kendaraan.nama AS nama_kendaraan, tbl_kendaraan.kprice AS k_price,  tbl_fasilitas.nama AS nama_fasilitas, tbl_fasilitas.fprice AS f_price, 
		tbl_promosi.nama AS nama_promosi, tbl_promosi.pprice AS p_price, tbl_jenis_bayar.jenis_bayar
		FROM tbl_transaksi 
		INNER JOIN tbl_penyewa ON tbl_transaksi.id_penyewa = tbl_penyewa.id INNER JOIN tbl_karyawan ON tbl_transaksi.id_karyawan = tbl_karyawan.id 
		INNER JOIN tbl_kendaraan ON tbl_transaksi.id_kendaraan = tbl_kendaraan.id INNER JOIN tbl_fasilitas ON tbl_transaksi.id_fasilitas = tbl_fasilitas.id 
		INNER JOIN tbl_promosi ON tbl_transaksi.id_promosi = tbl_promosi.id 
		INNER JOIN tbl_jenis_bayar ON tbl_transaksi.id_jenis_bayar = tbl_jenis_bayar.id
		");
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->get_where('tbl_transaksi', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function ubah($data, $id){
		$query = $this->update('tbl_transaksi', $data, ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_transaksi', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_transaksi', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cari_pend($date1, $date2){
		$query = $this->setQuery("SELECT *, tbl_transaksi.id, tbl_penyewa.nama AS nama_penyewa, tbl_karyawan.nama AS nama_karyawan, tbl_kendaraan.no_polisi AS nopol, 
		tbl_kendaraan.nama AS nama_kendaraan, tbl_kendaraan.kprice AS k_price,  tbl_fasilitas.nama AS nama_fasilitas, tbl_fasilitas.fprice AS f_price, 
		tbl_promosi.nama AS nama_promosi, tbl_promosi.pprice AS p_price, tbl_jenis_bayar.jenis_bayar
		FROM tbl_transaksi 
		INNER JOIN tbl_penyewa ON tbl_transaksi.id_penyewa = tbl_penyewa.id INNER JOIN tbl_karyawan ON tbl_transaksi.id_karyawan = tbl_karyawan.id 
		INNER JOIN tbl_kendaraan ON tbl_transaksi.id_kendaraan = tbl_kendaraan.id INNER JOIN tbl_fasilitas ON tbl_transaksi.id_fasilitas = tbl_fasilitas.id 
		INNER JOIN tbl_promosi ON tbl_transaksi.id_promosi = tbl_promosi.id INNER JOIN tbl_jenis_bayar ON tbl_transaksi.id_jenis_bayar = tbl_jenis_bayar.id
		WHERE tgl_pinjam BETWEEN '$date1' and '$date2'");
		$query = $this->execute();
		return $query;
	}

	public function detail($id){
		$query = $this->setQuery("SELECT *, 
		
		tbl_penyewa.nama AS nama_penyewa, tbl_karyawan.nama AS nama_karyawan, tbl_kendaraan.no_polisi AS nopol, 
		tbl_kendaraan.nama AS nama_kendaraan, tbl_kendaraan.kprice AS k_price,  tbl_fasilitas.nama AS nama_fasilitas, tbl_fasilitas.fprice AS f_price, 
		tbl_promosi.nama AS nama_promosi, tbl_promosi.pprice AS p_price, tbl_jenis_bayar.jenis_bayar  
		FROM tbl_transaksi 
		INNER JOIN tbl_penyewa ON tbl_transaksi.id_penyewa = tbl_penyewa.id 
		INNER JOIN tbl_karyawan ON tbl_transaksi.id_karyawan = tbl_karyawan.id 
		INNER JOIN tbl_kendaraan ON tbl_transaksi.id_kendaraan = tbl_kendaraan.id 
		INNER JOIN tbl_fasilitas ON tbl_transaksi.id_fasilitas = tbl_fasilitas.id 
		INNER JOIN tbl_promosi ON tbl_transaksi.id_promosi = tbl_promosi.id 
		INNER JOIN tbl_jenis_bayar ON tbl_transaksi.id_jenis_bayar = tbl_jenis_bayar.id 
		
		WHERE tbl_transaksi.id = $id");
		$query = $this->execute();
		return $query;
	}
}