<?php 

class M_Karyawan extends Model {
	public function lihat(){
		$query = $this->setQuery('SELECT nama, email, phone, tbl_level.level AS id_level,  tbl_karyawan.id AS id FROM tbl_karyawan INNER JOIN tbl_level ON tbl_level.id = tbl_karyawan.id_level');
		$query = $this->execute();
		return $query;
	}

	public function tambah($data){
		$query = $this->insert('tbl_karyawan', $data);
		$query = $this->execute();
		return $query;
	}

	public function lihat_id($id){
		$query = $this->get_where('tbl_karyawan', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function ubah($data, $id){
		$query = $this->update('tbl_karyawan', $data, ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function cek($id){
		$query = $this->get_where('tbl_karyawan', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}

	public function detail($id){
		$query = $this->setQuery("SELECT *, tbl_karyawan.id AS id_karyawan, tbl_karyawan.id_level AS id_level FROM tbl_karyawan INNER JOIN tbl_level ON tbl_level.id = tbl_karyawan.id_level where tbl_karyawan.id = $id");
		$query = $this->execute();
		return $query;
	}

	public function hapus($id){
		$query = $this->delete('tbl_karyawan', ['id' => $id]);
		$query = $this->execute();
		return $query;
	}
}