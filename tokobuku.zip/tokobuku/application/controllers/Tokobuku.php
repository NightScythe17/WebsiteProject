<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tokobuku extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');

		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('example.php',(array)$output);
	}

	public function offices()
	{
		$output = $this->grocery_crud->render();

		$this->_example_output($output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}

	public function author()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('flexigrid');//tema tabel
			$crud->set_table('author');//nama tabel
			$crud->set_subject('Author');//controller
			$crud->required_fields('author_id');//primary key
			$crud->columns('author_id','fullname','email');//atribut

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function book_category()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('flexigrid');
			$crud->set_table('book_category');
			$crud->set_subject('Book_Category');
			$crud->required_fields('book_category_id');
			$crud->columns('book_category_id','name');

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function level()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('flexigrid');
			$crud->set_table('level');
			$crud->set_subject('Level');
			$crud->required_fields('level_id');
			$crud->columns('level_id','name');

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function customer()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('flexigrid');
			$crud->set_table('customer');
			$crud->set_subject('Customer');
			$crud->required_fields('customer_id');
			$crud->columns('customer_id','name','email','no_member','gender','phone','address');

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function supplier()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('flexigrid');
			$crud->set_table('supplier');
			$crud->set_subject('Supplier');
			$crud->required_fields('supplier_id');
			$crud->columns('supplier_id','name','email','phone','address');

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function book()
	{
		if($this->session->userdata('employee_id') != NULL){
			$crud = new grocery_CRUD();
			$crud->set_table('book');

			$crud->set_relation_n_n('author', 'book_author', 'author', 'book_id', 'author_id', 'fullname');
			$crud->set_relation_n_n('category', 'book_bookcat', 'book_category', 'book_id', 'book_category_id', 'name');
			$crud->set_subject('book');
			$crud->columns('title', 'author', 'description', 'release_year', 'pages', 'price', 'stock');
			$output = $crud->render();
			$this->_example_output($output);
		}
		else{
			echo '<script language=JavaScript>alert("Anda Belum Login, Silahkan Login") 
			onclick=location.href="../auth"</script>';
		}
	}
}
