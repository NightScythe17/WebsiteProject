<?php defined ('BASEPATH') or exit('No direct script access allowed');


class Customer extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Customer_model');
	}

	public function index()
	{
		$data['customer'] = $this->Customer_model->customer_getAll();
		$this->load->view('admin/customer/v_Customer', $data);
	}

	public function add()
	{
		$name = strip_tags ($this->input->post ('i_name'));
		$email = strip_tags ($this->input->post ('i_email'));
		$no_member = strip_tags ($this->input->post ('i_no_member'));
		$gender = strip_tags ($this->input->post ('i_gender'));
		$phone = strip_tags ($this->input->post ('i_phone'));
		$address = strip_tags ($this->input->post ('i_address'));

		$data = array (
			'name' => $name,
			'email' => $email,
			'no_member' => $no_member,
			'gender' => $gender,
			'phone' => $phone,
			'address' =>$address
		);

		$x = $this->Customer_model->customer_cek($email);
		if ($x==Null){
			$this->Customer_model->customer_insert('customer', $data);
			echo '<script language=JavaScript>alert("Input berhasil") 
			onclick=location.href = document.referrer</script>';
		}
		else
		{
			echo '<script language=JavaScript>alert("Gagal! customer telah tersimpan sebelumnya") 
			onclick=history.go(-1)</script>';
		}
	}

	public function edit($id)
	{
		$data ['customer'] = $this->Customer_model->customer_getByID ($id);
		$name = strip_tags ($this->input->post ('i_name'));
		$email = strip_tags ($this->input->post ('i_email'));
		$no_member = strip_tags ($this->input->post ('i_no_member'));
		$gender = strip_tags ($this->input->post ('i_gender'));
		$phone = strip_tags ($this->input->post ('i_phone'));
		$address = strip_tags ($this->input->post ('i_address'));

		$data = array (
			'name' => $name,
			'email' => $email,
			'no_member' => $no_member,
			'gender' => $gender,
			'phone' => $phone,
			'address' =>$address
		);

		$x = $this->Customer_model->customer_cek ($email);
		if ($x==Null){
			$this->Customer_model->customer_update($id, 'customer', $data);
			echo '<script language=JavaScript>alert("Input berhasil")
			onclick=location.href = document.referrer</script>';
		}
		else {
			echo '<script language=JavaScript>alert("Gagal! customer telah tersimpan sebelumnya") 
			onclick=history.go(-1)</script>';
		}
	}

	public function delete ($id)
	{
		$this->Customer_model->customer_delete('customer', $id);
		echo '<script language=JavaScript>alert("Delete Berhasil") 
		onclick=history.go(-1)</script>';
	}

}
?>