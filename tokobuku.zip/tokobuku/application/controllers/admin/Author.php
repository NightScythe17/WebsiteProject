<?php defined ('BASEPATH') or exit('No direct script access allowed');


class Author extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Author_model');
	}

	public function index()
	{
		if($this->session->userdata('employee_id') != NULL){
			$data['author'] = $this->Author_model->author_getAll();
		$this->load->view('admin/author/v_Author', $data);
		}
		else{
			echo '<script language=JavaScript>alert("Anda Belum Login, Silahkan Login") 
			onclick=location.href="../auth"</script>';
		}
		
	}

	public function add()
	{
		$fullname = strip_tags ($this->input->post ('i_fullname'));
		$email = strip_tags ($this->input->post ('i_email'));

		$data = array (
			'fullname' => $fullname,
			'email' => $email
		);

		$x = $this->Author_model->author_cek($email);
		if ($x==Null){
			$this->Author_model->author_insert('author', $data);
			echo '<script language=JavaScript>alert("Input berhasil") 
			onclick=location.href = document.referrer</script>';
		}
		else
		{
			echo '<script language=JavaScript>alert("Gagal! author telah tersimpan sebelumnya") 
			onclick=history.go(-1)</script>';
		}
	}

	public function edit($id)
	{
		$data ['author'] = $this->Author_model->author_getByID ($id);
		$fullname = strip_tags ($this->input->post ('i_fullname'));
		$email = strip_tags ($this->input->post ('i_email'));

		$data = array (
			'fullname' => $fullname,
			'email' => $email
		);

		$x = $this->Author_model->author_cek ($email);
		if ($x==Null){
			$this->Author_model->author_update($id, 'author', $data);
			echo '<script language=JavaScript>alert("Input berhasil")
			onclick=location.href = document.referrer</script>';
		}
		else {
			echo '<script language=JavaScript>alert("Gagal! author telah tersimpan sebelumnya") 
			onclick=history.go(-1)</script>';
		}
	}

	public function delete ($id)
	{
		$this->Author_model->author_delete('author', $id);
		echo '<script language=JavaScript>alert("Delete Berhasil") 
		onclick=history.go(-1)</script>';
	}

}
?>