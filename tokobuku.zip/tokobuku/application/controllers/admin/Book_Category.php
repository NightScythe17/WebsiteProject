<?php defined ('BASEPATH') or exit('No direct script access allowed');


class Book_Category extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Book_Category_model');
	}

	public function index()
	{
		if($this->session->userdata('employee_id') != NULL){
			$data['book_category'] = $this->Book_Category_model->book_category_getAll();
		$this->load->view('admin/book_category/v_Book_Category', $data);
		}
		else{
			echo '<script language=JavaScript>alert("Anda Belum Login, Silahkan Login") 
			onclick=location.href="../auth"</script>';
		}
	}

	public function add()
	{
		$name = strip_tags ($this->input->post ('i_name'));

		$data = array (
			'name' => $name
		);

		$x = $this->Book_Category_model->book_category_cek($name);
		if ($x==Null){
			$this->Book_Category_model->book_category_insert('book_category', $data);
			echo '<script language=JavaScript>alert("Input berhasil") 
			onclick=location.href = document.referrer</script>';
		}
		else
		{
			echo '<script language=JavaScript>alert("Gagal! book category telah tersimpan sebelumnya") 
			onclick=history.go(-1)</script>';
		}
	}

	public function edit($id)
	{
		$data ['book_category'] = $this->Book_Category_model->book_category_getByID ($id);
		$name = strip_tags ($this->input->post ('i_name'));

		$data = array (
			'name' => $name
		);

		$x = $this->Book_Category_model->book_category_cek ($name);
		if ($x==Null){
			$this->Book_Category_model->book_category_update($id, 'book_category', $data);
			echo '<script language=JavaScript>alert("Input berhasil")
			onclick=location.href = document.referrer</script>';
		}
		else {
			echo '<script language=JavaScript>alert("Gagal! book category telah tersimpan sebelumnya") 
			onclick=history.go(-1)</script>';
		}
	}

	public function delete ($id)
	{
		$this->Book_Category_model->book_category_delete('book_category', $id);
		echo '<script language=JavaScript>alert("Delete Berhasil") 
		onclick=history.go(-1)</script>';
	}
}
?>