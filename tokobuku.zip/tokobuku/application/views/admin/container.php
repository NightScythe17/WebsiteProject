<!DOCTYPE html>
<html lang="en">
<main_head>
      <title>Container</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</main_head>

    <head>
        <?php $this->load->view("admin/_partials/head.php"); ?>
    </head>

    <body class="sb-nav-fixed">
        <?php $this->load->view("admin/_partials/navbar.php"); ?>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php $this->load->view("admin/_partials/sidebar.php"); ?>
            </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">

                        
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                       
                        <!-- Container 1 -->
        <con1>
            <div class="container-fluid">
                <div class="row">
                    <div class="col bg-warning">
                        <div class="text-dark text-center">
                        <h1>Container 1 - Gambar </h1>
                    
                        </div>
                </div>
            </div>

            
              <div class="row">
                    <div class="bg-primary text-dark text-center col-sm-4">
                        <img src="<?php echo base_url(); ?>assets/img/k2.jpg" width="80%" height="80%" style="display: block; margin: auto;">
                        <h3>Gedung Bonaventura</h3>
                    </div>

                    <div class="bg-secondary text-dark text-center col-sm-4">
                        <img src="<?php echo base_url(); ?>assets/img/l1.jpg" width="80%" height="80%" style="display: block; margin: auto;">
                        <h3>logo UAJY</h3>
                    </div>

                    <div class="container bg-success text-dark text-center col-sm-4">  
                        <img src="<?php echo base_url(); ?>assets/img/l2.png" width="80%" height="75%" style="display: block; margin: auto;"> 
                        <h3>Logo Himsi</h3>
                    </div>
              </div>
            </div>
        </con1>

<br></br>
    
    <!-- Container 2 -->
    <con2>
        <div class="container-fluid">
            <div class="row">
                <div class="col bg-success text-dark text-center">
                  <h1>Container 2 - Biodata Diri</h1> 
                </div>
            </div>
    
            
            <div class="row">

                <div class="bg-primary text-dark text-center col-sm-6">
                    <h3>Data Diri</h3>
                    <h5>Nama : Brayen Billion</h5>
                    <h5>NPM : 181709670 </h5>
                    <h5>Jenis Kelamin : Laki-laki</h5>
                    <h5>Tempat/Tanggal Lahir : Pangkalpinang/17-02-2000</h5>
                    <h5>Alamat : GG Batu Ruby </h5>
                    <h5>Minggu 3</h5>
                </div>

                <div class="bg-warning text-dark text-center col-sm-6">
                    <h3>Deskripsi</h3>
                    <h5>Apa ya gitulah..</h5>
                    </div>
            </div>
        </div>  
    </con2>
                    </div>

                </main>
                <?php $this->load->view("admin/_partials/footer.php"); ?>
            </div>
            
        </div>
        
        
    </body>
        <?php $this->load->view("admin/_partials/modal.php"); ?>
        <?php $this->load->view("admin/_partials/js.php"); ?>
    </html>

