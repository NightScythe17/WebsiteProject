<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $this->load->view("admin/_partials/head.php"); ?>
    </head>

    <body class="sb-nav-fixed">
        <?php $this->load->view("admin/_partials/navbar.php"); ?>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php $this->load->view("admin/_partials/sidebar.php"); ?>
            </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">

                        <center><h3> Supplier</h3></center>
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                        <!-- box header -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                List Supplier
                                <a type="button" class="btn btn-primary"data-toggle="modal" data-target="#addSupplier"> Add (+) </a>
                            </div>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th width="10%">ID</th>
                                                <th width="15%" >Name </th>
                                                <th width="10%">Email</th>
                                                
                                                <th width="15%">Phone</th>
                                                <th width="30%">address</th>
                                                <th width="10%">Action </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $x=1;
                                        foreach($supplier->result_array() as $i) :
                                        $id = $i['supplier_id'];
                                        $name = $i['name'];
                                        $email = $i['email']; 
                                        $phone = $i['phone'];
                                        $address = $i['address']; 
                                        ?>
                                        <tr>
                                            <td> <?php echo $x; ?> </td>
                                            <td> <?php echo $name; ?> </td>
                                            <td> <?php echo $email; ?> </td>
                                            
                                            <td> <?php echo $phone; ?>  </td>
                                            <td> <?php echo $address; ?>  </td>

                                            <td>
                                                <a class="btn btn-primary" data-toggle="modal" data-target="#editSupplier<?php echo $id; ?>">Edit</a>
                                                <a type="button" data-toggle="modal" data-target="#deleteSupplier<?php echo $id; ?>" class="btn btn-danger"> Delete </a>
                                            </td>
                                        </tr>
                                        <?php
                                        $x++;
                                        endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </main>
                <?php $this->load->view("admin/_partials/footer.php"); ?>
            </div>
            
        </div>
        <?php $this->load->view("admin/supplier/modal_supplier.php"); ?>
        <?php $this->load->view("admin/_partials/modal.php"); ?>
        <?php $this->load->view("admin/_partials/js.php"); ?>
    </body>
        
    </html>