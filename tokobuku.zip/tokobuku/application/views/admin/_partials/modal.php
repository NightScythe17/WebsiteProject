<!-- Modal Logout-->

            <!-- Fade -->
            <div class="modal fade" id="ModalLogout" tabindex="-1" role="dialog" aria-labelledby="LabellogoutModal" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                    
                    <!-- Modal Header -->
                        <div class="modal-header">
                            <h5 class="modal-title" id="LabellogoutModal">Logout Confirmation</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                    <!-- Modal Body -->
                        <div class="modal-body">
                        Apakah Anda ingin Log Out?
                        </div>

                    <!-- Modal footer -->
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <a class="nav-link" href="<?= base_url('auth/logout')?>">
                        <button type="button" class="btn btn-primary">  
                        Logout </button> </a>
                        </div>
                </div>
              </div>
            </div>