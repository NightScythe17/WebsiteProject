<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav <?php echo $this->uri->segment(2) == ''? 'active': ''?>">
                            <div class="sb-sidenav-menu-heading text-success">Core</div>
                            <a class="nav-link" href="">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link" href="<?= site_url("welcome/about")?>" >
                                <div class="sb-nav-link-icon"><i class="far fa-id-card"></i></div>
                                About
                            </a>
                            <a class="nav-link" href="<?= site_url("welcome/contact")?>">
                                <div class="sb-nav-link-icon"><i class="far fa-id-badge"></i></div> 
                                Contact
                            </a>
                            <div class="sb-sidenav-menu-heading text-success">Interface</div>
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Layouts
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="layout-static.html">Static Navigation</a>
                                    <a class="nav-link" href="layout-sidenav-light.html">Light Sidenav</a>
                                </nav>
                            </div>
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Pages
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                                        Authentication
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="login.html">Login</a>
                                            <a class="nav-link" href="register.html">Register</a>
                                            <a class="nav-link" href="password.html">Forgot Password</a>
                                        </nav>
                                    </div>
                                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                                        Error
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="401.html">401 Page</a>
                                            <a class="nav-link" href="404.html">404 Page</a>
                                            <a class="nav-link" href="500.html">500 Page</a>
                                        </nav>
                                    </div>
                                </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading text-success">Addons</div>
                            <a class="nav-link" href="charts.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Charts
                            </a>
                            <a class="nav-link" href="tables.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Tables
                            </a>
                            <div class="sb-sidenav-menu-heading text-success">Tugas</div>
                               <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTugas" aria-expanded="false" aria-controls="collapseTugas">
                                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                    Kumpulan Tugas
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                 </a>
                            <div class="collapse" id="collapseTugas" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link" href="<?php echo site_url('welcome/data_diri')?>">Data Diri</a>
                                        <a class="nav-link" href="<?php echo site_url('welcome/pengalaman')?>" >Pengalaman Pribadi</a>
                                        <a class="nav-link" href="<?php echo site_url('admin/container')?>">Container</a>
                                </nav>
                            </div>

                            <div class="sb-sidenav-menu-heading text-success">Grocery TokoBuku CRUD</div>
                               <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCRUD" aria-expanded="false" aria-controls="collapseCRUD">
                                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                    Tugas CRUD
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                 </a>
                            <div class="collapse" id="collapseCRUD" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link" href="<?php echo site_url('tokobuku/author')?>">Author</a>
                                        <a class="nav-link" href="<?php echo site_url('tokobuku/book_category')?>">Book Category</a>
                                        <a class="nav-link" href="<?php echo site_url('tokobuku/level')?>">Level</a>
                                        <a class="nav-link" href="<?php echo site_url('tokobuku/customer')?>">Customer</a>
                                        <a class="nav-link" href="<?php echo site_url('tokobuku/supplier')?>">Supplier</a>
                                        <a class="nav-link" href="<?php echo site_url('tokobuku/book')?>">Book</a>  
                                </nav>
                            </div>

                            <div class="sb-sidenav-menu-heading text-success">Transaksi</div>
                                 <a class="nav-link" href="<?php echo site_url('admin/penjualan')?>">
                                 <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                 Penjualan
                                 </a>
                                 
                                 <a class="nav-link" href="<?php echo site_url('admin/penjualan/list_penjualan')?>">
                                   <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                   Laporan Penjualan
                                </a>

                                <a class="nav-link" href="<?php echo site_url('admin/penjualan/chart') ?>">
                                   <div class="sb-nav-link-icon"><i class=" fas fa-chart-pie"></i></div>
                                   Chart Penjualan
                               </a>

                                <a class="nav-link" href="<?php echo site_url('admin/pembelian')?>">
                                 <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                 Pembelian
                                 </a>

                                 <a class="nav-link" href="<?php echo site_url('admin/pembelian/list_pembelian')?>">
                                   <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                   Laporan Pembelian
                                </a>

                                <a class="nav-link" href="<?php echo site_url('admin/pembelian/chart') ?>">
                                   <div class="sb-nav-link-icon"><i class=" fas fa-chart-pie"></i></div>
                                   Chart Pembelian
                               </a>

                             
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        Brayen Billion (admin)
                    </div>
                </nav>