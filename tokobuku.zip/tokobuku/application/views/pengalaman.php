<!DOCTYPE html>
<html lang="en">
<main_head>
      <title>Container</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</main_head>

    <head>
        <?php $this->load->view("admin/_partials/head.php"); ?>
    </head>

    <body class="sb-nav-fixed">
        <?php $this->load->view("admin/_partials/navbar.php"); ?>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php $this->load->view("admin/_partials/sidebar.php"); ?>
            </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">

                        
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                 
    <con1>
			<div class="container-fluid">
				<div class="row">
					<div class="col bg-danger">
						<div class="text-dark text-center">
					  	<h1>Pengalaman Diri</h1>
						</div>
				</div>
			</div>

			<div class="row">
				    <div class="bg-warning text-dark text-left col-sm-12">
				     	<p>Organisasi Himsi</p> 
						<p>Pernah ikut pramuka</p>
						<p>Organisasi UNISEC</p>
						<p>Panitia</p>
					</div>
			</div>		
                    

                    </div>

                </main>
                <?php $this->load->view("admin/_partials/footer.php"); ?>
            </div>
            
        </div>
        
        
    </body>
        <?php $this->load->view("admin/_partials/modal.php"); ?>
        <?php $this->load->view("admin/_partials/js.php"); ?>
    </html>