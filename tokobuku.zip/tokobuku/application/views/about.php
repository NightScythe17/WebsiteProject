<!DOCTYPE html>
<html lang="en">
<main_head>
      <title>Container</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</main_head>

    <head>
        <?php $this->load->view("admin/_partials/head.php"); ?>
    </head>

    <body class="sb-nav-fixed">
        <?php $this->load->view("admin/_partials/navbar.php"); ?>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php $this->load->view("admin/_partials/sidebar.php"); ?>
            </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">

                        
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                 
    <h1>About US</h1>
<p>Ini halaman about us</p>
                    

                    </div>

                </main>
                <?php $this->load->view("admin/_partials/footer.php"); ?>
            </div>
            
        </div>
        
        
    </body>
        <?php $this->load->view("admin/_partials/modal.php"); ?>
        <?php $this->load->view("admin/_partials/js.php"); ?>
    </html>