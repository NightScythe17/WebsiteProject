 <?php
        $connection = mysqli_connect('localhost', 'root','') or die("koneksi gagal");
        mysqli_select_db($connection,'tokobuku') or die("koneksi gagal");
        $sqli = mysqli_query($connection,"SELECT * FROM level ORDER BY name ASC;");
        ?>
 <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Create Account Employee</h3></div>
                                    <div class="card-body">
                                        <form class="user" method="post" action="<?php echo base_url('auth/registration'); ?>">
                                            
                                                    <div class="form-group">
                                                        <label class="small mb-1">Nama</label>
                                                        <input class="form-control py-4" id="name" type="text" name="name" value="<?= set_value('name'); ?>" placeholder="Enter fullname" />
                                                        <?= form_error('name', '<small class="text-danger">', '</small>') ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="small mb-1" >NIP</label>
                                                        <input class="form-control py-4" id="nip" type="text" name="nip" value="<?= set_value('nip'); ?>" placeholder="Enter NIP" />
                                                        <?= form_error('nip', '<small class="text-danger">', '</small>') ?>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                        <label class="small mb-1">Email</label>
                                                        <input class="form-control py-4" id="email" type="text" name="email" value="<?= set_value('email'); ?>" placeholder="Enter Email address" />
                                                        <?= form_error('email', '<small class="text-danger">', '</small>') ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="small mb-1">Phone</label>
                                                        <input class="form-control py-4" id="phone" type="text" name="phone" value="<?= set_value('phone'); ?>" placeholder="Enter Phone" />
                                                        <?= form_error('phone', '<small class="text-danger">', '</small>') ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="small mb-1">Address</label>
                                                        <input class="form-control py-4" id="address" type="text" name="address" value="<?= set_value('address'); ?>" placeholder="Enter Address" />
                                                        <?= form_error('address', '<small class="text-danger">', '</small>') ?>
                                                    </div>

                                            <div class="form-row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="small mb-1">Gender</label>
                                                        <input class="form-control py-4" id="gender" type="text" name="gender" value="<?= set_value('gender'); ?>" placeholder="Enter Gender" />
                                                        <?= form_error('gender', '<small class="text-danger">', '</small>') ?>
                                                    </div>
                                                </div>

                                                
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="title" class="col-sm-4 control-label"> Level</label>
                                                    <div class="col-lg-8">
                                                        <select class="form-control" id="level" name="level" required>
                                                            <option disabled selected>-Pilih Level-</option>

                                                            <?php if (mysqli_num_rows($sqli)>0){ ?>
                                                                    <?php while ($row = mysqli_fetch_array($sqli)) { ?>
                                                                        <option value=<?php echo $row['level_id'] ?>> <?php echo $row['name'] ?> </option>
                                                                        <?php } ?>
                                                                    <?php } ?>
                                                        </select>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="small mb-1" for="inputPassword">Password</label>
                                                        <input class="form-control py-4" id="password1" type="password" name="password1" placeholder="Enter Password " />
                                                        <?= form_error('password1', '<small class="text-danger">', '</small>') ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="small mb-1" for="inputConfirmPassword">Confirm Password</label>
                                                        <input class="form-control py-4" id="password2" type="password" name="password2" placeholder="Confirm password" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-block" >Create Account</button></div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center">
                                        <div class="small"><a href="<?= base_url('auth'); ?>">Have an Employee account? Go to login</a></div>
                                    </div>
                                    <div class="card-footer text-center">
                                        <div class="small"><a href="<?= base_url('authuser'); ?>">Have an User account? Go to login</a></div>
                                    </div>
                                    <div class="card-footer text-center">
                                        <div class="small"><a href="<?= base_url('authuser/registration'); ?>">Need an User account? Sign Up!</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2020</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>