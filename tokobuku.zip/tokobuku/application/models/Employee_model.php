<?php defined ('BASEPATH') or exit('No derict script access allowed');

class Employee_model extends CI_Model
{
	public function get_by_role()
	{
		$this->db->select('employee.*, level.level_id AS level_id');
		$this->db->join('level', 'employee.level_id = level.level_id');
		$this->db->from('employee');
		$query = $this->db->get();
		return $query->result();
	}
}